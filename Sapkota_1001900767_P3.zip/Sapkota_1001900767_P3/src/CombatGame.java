public class CombatGame {
    public static void main(String[] args) {
        new GUIController();
    }
}
